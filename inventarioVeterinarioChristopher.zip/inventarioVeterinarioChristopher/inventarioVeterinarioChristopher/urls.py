from django.contrib import admin
from django.urls import path, include
from django.views.generic.base import TemplateView
from gestorUser.views import *
from django.contrib.auth.views import LoginView, LogoutView
from gestorProducts.views import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include("django.contrib.auth.urls")),
    path('iniciar_sesion/', LoginView.as_view(template_name="gestorUser/login.html"), name="loginn"),
    path('registro/', registro, name='registro'),
    path("", TemplateView.as_view(template_name="home.html"), name="home"),
    path('dashboard/', dashboard, name='dashboard'),
    path('viewProducto/', viewProductos, name='lista_producto'),
    path('viewCategoria/', viewCategorias, name='lista_categoria'),
    path('addProducto/', addProducto, name='agregarProducto'),
    path('deleteProducto/<int:id>', deleteProducto, name='deleteProducto'),
    path('editProducto/<int:id>', editProducto, name='editProducto'),
    path('editCategoria/<int:id>', editCategoria, name='editCategoria'),
    path('addCategoria/', addCategoria, name='agregarCategoria'),
    path('deleteCategoria/<int:id>', deleteCategoria, name='deleteCategoria'),
]
