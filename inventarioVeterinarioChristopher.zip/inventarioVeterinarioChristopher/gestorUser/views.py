from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import RegistroForm

@login_required
def dashboard(request):
    if request.user.is_superuser:
        data = {
        'nombre':'Chucky PD',
        'profesion':'Clinica veterinaria',
        'presentacion':'La Clínica Veterinaria Chuchy PD es un refugio de salud, bienestar y amor para las mascotas. Nuestra pasión y compromiso por el cuidado de los animales es evidente en cada aspecto de nuestra clínica. Aquí, nos dedicamos a ofrecer una atención veterinaria excepcional, combinando la experiencia de profesionales altamente capacitados con un ambiente amigable y compasivo para las mascotas y sus dueños',
        'imagen1':'https://estaticos-cdn.prensaiberica.es/clip/c7cf76a0-d2ee-4937-87d5-fc57f2f7d35f_16-9-discover-aspect-ratio_default_0.jpg',
        'direc':'Aveida San Miguel 31 ote.'
}   

        return render(request, 'gestorUser/dashboard.html', data)
    else: 
        data = {
        'nombre':'Chucky PD',
        'profesion':'Clinica veterinaria',
        'presentacion':'La Clínica Veterinaria Chucky PD es un refugio de salud, bienestar y amor para las mascotas. Nuestra pasión y compromiso por el cuidado de los animales es evidente en cada aspecto de nuestra clínica. Aquí, nos dedicamos a ofrecer una atención veterinaria excepcional, combinando la experiencia de profesionales altamente capacitados con un ambiente amigable y compasivo para las mascotas y sus dueños',
        'imagen1':'https://estaticos-cdn.prensaiberica.es/clip/c7cf76a0-d2ee-4937-87d5-fc57f2f7d35f_16-9-discover-aspect-ratio_default_0.jpg',
        'direc':'Aveida San Miguel 31 ote.'
}   
    return render(request, 'gestorUser/dashboard_user.html', data)

from django.contrib.auth.forms import AuthenticationForm

def registro(request):
    if request.method == 'POST':
        form = RegistroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirección al formulario de inicio de sesión
    else:
        form = RegistroForm()

    return render(request, 'gestorUser/registro.html', {'form': form})
