from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.password_validation import validate_password

class RegistroForm(UserCreationForm):
    username = forms.CharField(
        label='Nombre de usuario',
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        help_text='Requerido. 150 caracteres como máximo. Únicamente letras, dígitos y @/./+/-/_'
    )

    password1 = forms.CharField(
        label='Contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        help_text=(
            'Su contraseña no puede asemejarse tanto a su otra información personal. '
            'Debe contener al menos 8 caracteres. No puede ser completamente numérica.'
        )
    )

    password2 = forms.CharField(
        label='Confirmar contraseña',
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = User
        fields = ('username', 'password1', 'password2')
