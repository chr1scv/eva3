from django.shortcuts import render
from . import forms
from gestorProducts.models import Productos, Categorias
from django.urls import reverse
from django.http import HttpResponseRedirect

def viewCategorias(request):
    categoria = Categorias.objects.all()
    data = {'categoria': categoria}
    return render(request, 'gestorProducts/viewCategoria.html', data)


def viewProductos(request):
    productos = Productos.objects.all()
    data = {'productos': productos}
    return render(request, 'gestorProducts/viewProducto.html', data)

def addProducto(request):

    form = forms.Producto()

    if request.method == 'POST':
        form = forms.Producto(request.POST)
        if form.is_valid():
            print("Formulario valido")
            form.save()
            return HttpResponseRedirect(reverse('lista_producto'))

    data = {'form': form,
            'titulo':'Agregar Producto'
            }
    return render(request, 'gestorProducts/formProducto.html',data)


def deleteProducto(request, id):
    producto = Productos.objects.get(id = id)
    producto.delete()
    return HttpResponseRedirect(reverse('lista_producto'))

def editProducto(request, id):

    producto = Productos.objects.get(id=id)

    form = forms.Producto(instance=producto)
    if request.method == 'POST':
        form = forms.Producto(request.POST, instance=producto)
        if form.is_valid():
            print("Formulario valido")
            form.save()
            return HttpResponseRedirect(reverse('lista_producto'))
        else:
            print("Errores: ",form.errors)

    data = {'form': form,
            'titulo':'Editar Producto'
            }
    return render(request, 'gestorProducts/formProducto.html',data)

def addCategoria(request):

    form = forms.Categoria()

    if request.method == 'POST':
        form = forms.Categoria(request.POST)
        if form.is_valid():
            print("Formulario valido")
            form.save()
            return HttpResponseRedirect(reverse('lista_categoria'))

    data = {'form': form,
            'titulo':'Agregar Categoria'
            }
    return render(request, 'gestorProducts/formCategoria.html',data)


def deleteCategoria(request, id):
    """ Buscar la producto correspondiente con su id """
    categoria = Categorias.objects.get(id = id)
    categoria.delete()
    return HttpResponseRedirect(reverse('lista_categoria'))


def editCategoria(request, id):
    """ Buscamos la producto a editar """
    categoria = Categorias.objects.get(id=id)
    """ Generar formulario con datos de la producto """
    form = forms.Categoria(instance=categoria)
    if request.method == 'POST':
        form = forms.Categoria(request.POST, instance=categoria)
        if form.is_valid():
            print("Formulario valido")
            form.save()
            return HttpResponseRedirect(reverse('lista_categoria'))
        else:
            print("Errores: ",form.errors)

    data = {'form': form,
            'titulo':'Editar Categoria'
            }
    return render(request, 'gestorProducts/formCategoria.html',data)
