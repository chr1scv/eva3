from django import forms
from gestorProducts.models import Productos, Categorias
from django.core import validators

class Producto(forms.Form):

    nombre = forms.CharField(
        validators=[validators.MinLengthValidator(2),
            validators.MaxLengthValidator(20)]
    )
    categoria = forms.ModelChoiceField(queryset=Categorias.objects.all())
    descripcion = forms.CharField(max_length=30)
    valor = forms.IntegerField()

    nombre.widget.attrs['class'] = 'form-control'
    categoria.widget.attrs['class'] = 'form-control'
    descripcion.widget.attrs['class'] = 'form-control'
    valor.widget.attrs['class'] = 'form-control'

    class Meta:
        model = Productos
        fields = '__all__'


class Producto(forms.ModelForm):

    nombre = forms.CharField(
        validators=[validators.MinLengthValidator(2),
            validators.MaxLengthValidator(20)]
    )
    categoria = forms.ModelChoiceField(queryset=Categorias.objects.all())
    descripcion = forms.CharField(max_length=30)
    valor = forms.IntegerField()


    nombre.widget.attrs['class'] = 'form-control'
    categoria.widget.attrs['class'] = 'form-control'
    descripcion.widget.attrs['class'] = 'form-control'
    valor.widget.attrs['class'] = 'form-control'

    class Meta:
        model = Productos
        fields = '__all__'


class Categoria(forms.Form):


    nombre = forms.CharField(
        validators=[validators.MinLengthValidator(2),
            validators.MaxLengthValidator(20)]
    )


    nombre.widget.attrs['class'] = 'form-control'
    
class Categoria(forms.ModelForm):


    nombre = forms.CharField(
        validators=[validators.MinLengthValidator(2),
                    validators.MaxLengthValidator(20)]
    )
        
    nombre.widget.attrs['class'] = 'form-control'
    
    class Meta:
        model = Categorias
        fields = '__all__'
